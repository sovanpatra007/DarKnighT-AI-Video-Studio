# Kaggle notebook integration notes

Kaggle GPU notebooks are temporary interactive compute, not a durable worker service. Phase 1/2 does not expose a public job-claim endpoint yet.

For now:
1. Use Kaggle to test image/video inference models in isolated notebooks.
2. Keep the web app, API, Postgres and Redis on a persistent host.
3. Save generated outputs to Kaggle `/kaggle/working` during a session, then transfer to durable object storage.
4. Never put long-lived provider secrets in a public notebook or committed notebook output.

Phase 3 will add an authenticated worker registration + job lease + signed upload endpoint before a Kaggle worker is connected.
