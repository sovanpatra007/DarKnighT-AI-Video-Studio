from pydantic import BaseModel, EmailStr, Field
from typing import Literal

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=72)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=72)

class UserResponse(BaseModel):
    id: str
    email: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class CreateVideoRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=5000)
    input_mode: Literal["topic", "script"] = "topic"
    language: Literal["Hindi", "English", "Bengali"] = "Hindi"
    duration_seconds: int = Field(default=60, ge=15, le=600)
    aspect_ratio: Literal["9:16", "16:9", "1:1"] = "9:16"
    visual_style: str = Field(default="3D animated", max_length=80)
    voice: str = Field(default="Hindi male", max_length=80)
    category: str = Field(default="general", max_length=60)
