import os, subprocess, tempfile
from pathlib import Path
from .queue import celery_app
from .database import SessionLocal
from .models import VideoJob

@celery_app.task(name="studio.generate_video", bind=True)
def generate_video(self, job_id: str):
    db = SessionLocal()
    try:
        job = db.get(VideoJob, job_id)
        if not job:
            return {"status": "missing"}
        job.status, job.progress, job.message = "processing", 10, "Preparing demo render"
        db.commit()

        # This is a demo slate, not AI-generated footage. Replace with the provider pipeline in Phase 3.
        work = Path(tempfile.mkdtemp(prefix="darknight-"))
        output = work / f"{job_id}.mp4"
        req = job.request_data
        duration = min(max(int(req.get("duration_seconds", 30)), 5), 60)
        safe_text = "DarKnighT AI Video Studio - DEMO RENDER"
        cmd = [
            "ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=0x10131b:s=720x1280:r=24",
            "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100",
            "-t", str(duration), "-vf",
            f"drawtext=text='{safe_text}':fontcolor=white:fontsize=30:x=(w-text_w)/2:y=(h-text_h)/2",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(output)
        ]
        subprocess.run(cmd, check=True, capture_output=True, timeout=180)
        job.status, job.progress, job.message = "demo_ready", 100, "Demo MP4 rendered; connect AI providers for real generated scenes"
        job.output_path = str(output)
        db.commit()
        return {"job_id": job_id, "status": job.status, "output_path": str(output)}
    except Exception as exc:
        db.rollback()
        job = db.get(VideoJob, job_id)
        if job:
            job.status, job.message, job.error = "failed", "Render failed", str(exc)[:2000]
            db.commit()
        raise
    finally:
        db.close()
