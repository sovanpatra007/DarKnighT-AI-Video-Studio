from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from .config import settings
from .database import Base, engine, get_db
from .models import User, Project, VideoJob
from .schemas import RegisterRequest, LoginRequest, CreateVideoRequest
from .security import hash_password, verify_password, create_access_token
from .deps import current_user
from .queue import celery_app

Base.metadata.create_all(bind=engine)

app = FastAPI(title="DarKnighT AI Video Studio API", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"ok": True, "service": "darknight-studio-api"}

@app.post("/api/v1/auth/register")
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(email=email, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": create_access_token(user.id), "token_type": "bearer",
            "user": {"id": user.id, "email": user.email}}

@app.post("/api/v1/auth/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == payload.email.lower()))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return {"access_token": create_access_token(user.id), "token_type": "bearer",
            "user": {"id": user.id, "email": user.email}}

@app.get("/api/v1/auth/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "email": user.email}

@app.get("/api/v1/projects")
def list_projects(user: User = Depends(current_user), db: Session = Depends(get_db)):
    projects = db.scalars(select(Project).where(Project.owner_id == user.id).order_by(Project.created_at.desc())).all()
    return [{"id": p.id, "title": p.title, "created_at": p.created_at.isoformat()} for p in projects]

@app.post("/api/v1/videos")
def create_video(payload: CreateVideoRequest, user: User = Depends(current_user), db: Session = Depends(get_db)):
    title = payload.prompt.strip().splitlines()[0][:180]
    project = Project(owner_id=user.id, title=title or "Untitled video")
    db.add(project)
    db.flush()
    job = VideoJob(project_id=project.id, owner_id=user.id, prompt=payload.prompt,
                   request_data=payload.model_dump(), status="queued", progress=0,
                   message="Waiting for generation worker")
    db.add(job)
    db.commit()
    db.refresh(job)
    try:
        celery_app.send_task("studio.generate_video", args=[job.id])
    except Exception:
        job.message = "Saved, but queue is unavailable. Start Redis and worker."
        db.commit()
    return {"id": job.id, "project_id": project.id, "status": job.status,
            "progress": job.progress, "message": job.message}

@app.get("/api/v1/jobs/{job_id}")
def get_job(job_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    job = db.scalar(select(VideoJob).where(VideoJob.id == job_id, VideoJob.owner_id == user.id))
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return {"id": job.id, "project_id": job.project_id, "status": job.status,
            "progress": job.progress, "message": job.message,
            "output_available": bool(job.output_path), "error": job.error}
