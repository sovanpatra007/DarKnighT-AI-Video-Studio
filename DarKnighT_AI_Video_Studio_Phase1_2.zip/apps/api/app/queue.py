from celery import Celery
from .config import settings

celery_app = Celery("darknight_studio", broker=settings.redis_url, backend=settings.redis_url)
celery_app.conf.update(
    task_track_started=True,
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    task_acks_late=True,
    worker_prefetch_multiplier=1,
)
import app.tasks  # noqa: E402,F401 — register task
