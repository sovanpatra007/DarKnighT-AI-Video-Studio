import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "DarKnighT AI Video Studio", description: "Create complete AI videos from a prompt or script." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
