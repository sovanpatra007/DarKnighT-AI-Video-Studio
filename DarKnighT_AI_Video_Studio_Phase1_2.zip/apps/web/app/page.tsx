"use client";
import { useEffect, useState } from "react";
const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
type Job = {id:string;project_id:string;status:string;progress:number;message:string};
export default function Home() {
 const [token,setToken]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
 const [authMode,setAuthMode]=useState("login"); const [prompt,setPrompt]=useState(""); const [inputMode,setInputMode]=useState("topic");
 const [language,setLanguage]=useState("Hindi"); const [duration,setDuration]=useState("60"); const [style,setStyle]=useState("3D animated");
 const [category,setCategory]=useState("kids"); const [busy,setBusy]=useState(false); const [job,setJob]=useState<Job|null>(null);
 const [error,setError]=useState(""); const [projects,setProjects]=useState<any[]>([]);
 useEffect(()=>{const saved=localStorage.getItem("dk_token");if(saved)setToken(saved)},[]);
 useEffect(()=>{if(token){localStorage.setItem("dk_token",token);loadProjects()}},[token]);
 async function request(path:string, options:any={}) {
   const res=await fetch(`${API}${path}`,{...options,headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{}) ,...(options.headers||{})}});
   const data=await res.json().catch(()=>({}));
   if(!res.ok)throw new Error(data.detail||"Request failed");
   return data;
 }
 async function authenticate(){
   setError("");setBusy(true);
   try{const data=await request(`/api/v1/auth/${authMode}`,{method:"POST",body:JSON.stringify({email,password})});setToken(data.access_token)}
   catch(e:any){setError(e.message)}finally{setBusy(false)}
 }
 async function loadProjects(){try{setProjects(await request("/api/v1/projects"))}catch{}}
 async function create(){
   setError("");setBusy(true);setJob(null);
   try{const data=await request("/api/v1/videos",{method:"POST",body:JSON.stringify({prompt,input_mode:inputMode,language,duration_seconds:Number(duration),aspect_ratio:"9:16",visual_style:style,voice:`${language} male`,category})});setJob(data);loadProjects()}
   catch(e:any){setError(e.message)}finally{setBusy(false)}
 }
 useEffect(()=>{
   if(!job || ["demo_ready","failed"].includes(job.status))return;
   const timer=setInterval(async()=>{try{const fresh=await request(`/api/v1/jobs/${job.id}`);setJob(fresh)}catch{}},3000);
   return()=>clearInterval(timer);
 },[job?.id,job?.status]);
 function logout(){localStorage.removeItem("dk_token");setToken("");setJob(null);setProjects([])}
 if(!token)return <main className="shell"><header className="top"><div className="brand">🦇 DarKnighT <span className="muted">AI VIDEO STUDIO</span></div><span className="muted">Phase 1 + 2</span></header><section className="auth panel"><h1>{authMode==="login"?"Welcome back":"Create your account"}</h1><p className="muted">Sign in to save projects and submit generation jobs.</p><div className="tabs"><button className={authMode==="login"?"selected":""} onClick={()=>setAuthMode("login")}>Sign in</button><button className={authMode==="register"?"selected":""} onClick={()=>setAuthMode("register")}>Register</button></div><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></div><div className="field"><label>Password (10+ characters)</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)}/></div><button className="btn" disabled={busy} onClick={authenticate}>{busy?"Please wait...":authMode==="login"?"Sign in":"Create account"}</button>{error&&<p className="error">{error}</p>}</section></main>;
 return <main className="shell">
  <header className="top"><div className="brand">🦇 DarKnighT <span className="muted">AI VIDEO STUDIO</span></div><button className="btn" onClick={logout}>Sign out</button></header>
  <div className="layout"><aside className="nav"><a className="active" href="#">✦ Create video</a><a href="#projects">▣ My projects</a><a href="#pipeline">◈ Pipeline</a></aside>
   <section><div className="hero"><p className="muted">YOUR AI VIDEO WORKSPACE</p><h1>Turn an idea into a video.</h1><p className="muted">Create stories, explainers, marketing videos and more.</p></div>
    <div className="panel"><h2 style={{marginTop:0}}>Create a new video</h2>
     <div className="field"><label>Input type and category</label><div className="grid"><select value={inputMode} onChange={e=>setInputMode(e.target.value)}><option value="topic">Start with a topic</option><option value="script">I have a script</option></select><select value={category} onChange={e=>setCategory(e.target.value)}><option value="kids">Kids stories</option><option value="education">Education</option><option value="technology">Technology</option><option value="marketing">Marketing</option><option value="general">General</option></select></div><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Describe your video or paste your script..."/></div>
     <div className="grid"><div className="field"><label>Language</label><select value={language} onChange={e=>setLanguage(e.target.value)}><option>Hindi</option><option>English</option><option>Bengali</option></select></div><div className="field"><label>Duration</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="30">30 seconds</option><option value="45">45 seconds</option><option value="60">60 seconds</option><option value="90">90 seconds</option><option value="180">3 minutes</option></select></div><div className="field"><label>Visual style</label><select value={style} onChange={e=>setStyle(e.target.value)}><option>3D animated</option><option>2D cartoon</option><option>Cinematic realistic</option><option>Motion graphics</option><option>Slideshow</option></select></div><div className="field"><label>Output</label><input readOnly value="9:16 · YouTube Shorts"/></div></div>
     <button className="btn" disabled={busy||prompt.trim().length<3} onClick={create}>{busy?"Submitting...":"✦ Generate demo job"}</button>
     <p className="hint">Current worker creates a labelled demo slate only. Real AI scene, voice and video providers are added in Phase 3.</p>
     {error&&<p className="error">{error}</p>}
     {job&&<div className="status"><b>Job: {job.status}</b><p>{job.message}</p><small>{job.id}</small></div>}
    </div>
    <div id="projects" className="panel" style={{marginTop:16}}><h3>My projects</h3>{projects.length?projects.map(p=><div className="project" key={p.id}><b>{p.title}</b><p className="hint">{new Date(p.created_at).toLocaleString()}</p></div>):<p className="muted">Your projects will appear here.</p>}</div>
   </section>
  </div>
 </main>;
}
