# DarKnighT AI Video Studio — Phase 1 & 2

A mobile-friendly full-stack SaaS foundation with Next.js, FastAPI, PostgreSQL, Redis, Celery, JWT authentication, project/job persistence and a mock render worker.

> The mock worker creates a clearly labelled demo MP4. It is not an AI-generated video. Real script/TTS/image/video provider adapters are Phase 3.

## Requirements
- Docker Engine + Docker Compose v2
- Git (optional)
- A Kaggle account for optional GPU experiments

## Local setup

```bash
cp .env.example .env
# Change SECRET_KEY and database passwords before exposing anything.
docker compose up --build -d
docker compose ps
```

Open:
- Web dashboard: http://localhost:3000
- API docs: http://localhost:8000/docs
- API health: http://localhost:8000/health

Stop:
```bash
docker compose down
```
Stop and delete local database/media volumes (DESTRUCTIVE):
```bash
docker compose down -v
```

## Features implemented
- Register/login using bcrypt password hashes and JWT bearer tokens
- Authenticated project creation
- Persistent PostgreSQL users/projects/jobs
- Celery + Redis background job queue
- Job status polling from the dashboard
- Demo MP4 rendering with FFmpeg
- Docker Compose development stack

## Free deployment recommendation

For a zero-budget prototype:
- Frontend: Vercel Hobby (personal/non-commercial usage constraints apply; review its terms)
- API + worker: Render Free web service / worker alternatives only if their current service type is eligible; free services can sleep/restart.
- Database: use local Docker during development. For hosted tests, Supabase free DB is an alternative, but it can pause after inactivity and has quotas.
- Redis: use a free compatible Redis service only after checking current quotas, or keep a single API process with a database-backed queue for a no-Redis prototype.
- Media: use an object storage free tier only after checking egress/storage limits.

Important: Render's free Postgres expires after 30 days and free web services have no persistent disk. Do not put important user data there. Free plans are for testing, not reliable production. Keep backups. Sources: Render free plan docs and Vercel Hobby pricing.

## Kaggle notebook role
Kaggle is an on-demand compute worker / experimentation environment, not the website host, database, or always-on queue consumer. GPU availability and quota are limited and sessions terminate. Use it to test local inference or render short jobs, then upload output to durable object storage. Never put permanent API secrets in a public notebook.

## Security checklist before public launch
- Set strong unique `SECRET_KEY`, database password and Redis password.
- Configure exact production `CORS_ORIGINS`.
- Add email verification, password reset, rate limits and account deletion.
- Add tenant quotas, API spend caps and moderation.
- Use private object storage and signed URLs.
- Add database backups and migration tooling.
- Do not expose Postgres/Redis ports publicly.
- Do not accept untrusted arbitrary FFmpeg filter strings or shell commands.

## API routes
- `GET /health`
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `POST /api/v1/videos` (authenticated)
- `GET /api/v1/jobs/{job_id}` (authenticated; owner only)
- `GET /api/v1/projects` (authenticated)
